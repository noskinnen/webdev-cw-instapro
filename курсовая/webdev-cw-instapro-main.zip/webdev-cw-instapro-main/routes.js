// Файл со списком страниц приложения
export const POSTS_PAGE = "posts";
export const USER_POSTS_PAGE = "user-posts";
export const AUTH_PAGE = "auth";
export const ADD_POSTS_PAGE = "add-post";
export const LOADING_PAGE = "loading";
